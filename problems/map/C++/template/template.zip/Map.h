#include <bits/stdc++.h>

class Map {
public:
    // You must implement the following public methods:

    void set(const std::string& key, const std::string& val);
    std::string get(const std::string& key) const;
    int size() const;
private:
    // Add private state or methods here:

};